scp main root@182.61.186.204:/root/chain
scp main root@182.61.164.17:/root/chain
scp main root@182.61.110.176:/root/chain
scp main root@106.12.186.114:/root/chain
scp main root@106.12.186.120:/root/chain
